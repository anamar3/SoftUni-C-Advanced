﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarManufacturer
{
    class Class1
    {
    }
}
